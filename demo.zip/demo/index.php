<?php
include 'conn.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>moiveWorld</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container-fluid p-5 bg-primary text-white text-center">
  <h1>Movie world</h1>
  <p>One App with the movies you love or hate</p> 
</div>
  
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-8">
      <?php 
      global $conn;
      $sql = "SELECT id, title, descr, adate, likes,hates FROM movies";
      $result = $conn->query($sql);
      
      if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
      ?>
    <div class="card" style="margin-bottom:10px;">
  <div class="card-header"><?php echo $row['title']; ?> | Date:<?php echo $row['adate'];?></div>
  <div class="card-body"><?php echo $row['descr']; ?></div>
  <div class="card-footer">
      Likes</button> :<?php echo $row['likes'];?> | 
      Hates</button>:<?php echo $row['hates'];?>
   
  </div>
</div>
<?php 
        }
      }
?>

      
    </div>
    <div class="col-sm-4">
      <?php 
      if ($_SESSION['user']){
        ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#nmovie">New Movie</button> | welcome, <?php echo $_SESSION['user'];?>
        <?php
      }else{
      ?>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#login">Login</button>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#signup">
  Sign Up
</button>
<?php 
      }
?>
<!-- The Modal -->
<div class="modal" id="signup">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Signup</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <form method="post">
  <div class="mb-3 mt-3">
    <label for="username" class="form-label">Username:</label>
    <input type="text" class="form-control" id="username" placeholder="Enter username" name="uname">
  </div>
  <div class="mb-3">
    <label for="pwd" class="form-label">Password:</label>
    <input type="text" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
  </div>
  <button type="submit" class="btn btn-primary" name="signupButton">Submit</button>
</form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>



<div class="modal" id="login">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Login</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <form method="post">
  <div class="mb-3 mt-3">
    <label for="username" class="form-label">Username:</label>
    <input type="text" class="form-control" id="username" placeholder="Enter username" name="uname">
  </div>
  <div class="mb-3">
    <label for="pwd" class="form-label">Password:</label>
    <input type="text" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
  </div>
  <button type="submit" class="btn btn-primary" name="loginButton">Submit</button>
</form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
    <div class="card">
  <div class="card-header">Sort By:</div>
  <div class="card-body">Likes</div>
  <div class="card-body">Hates</div>
  <div class="card-footer">Dates</div>
  </div>
    </div>
  </div>
</div>

<div class="modal" id="nmovie">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">New movie</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <form method="post">
  <div class="mb-3 mt-3">
    <label for="title" class="form-label">Title:</label>
    <input type="text" class="form-control" id="title" placeholder="Enter title" name="title">
  </div>
  <div class="mb-3">
    <label for="descr" class="form-label">Description:</label>
    <input type="text" class="form-control" id="descr" placeholder="Enter description" name="descr">
  </div>
  <button type="submit" class="btn btn-primary" name="nmovieButton">Submit</button>
</form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

</body>
</html>

<?php 


function signupFunction(){
  global $conn;

  $uname = $conn -> real_escape_string($_POST['uname']);
  $pwd = $conn -> real_escape_string($_POST['pwd']);

  
  $sql="INSERT INTO users (username,pwd) VALUES ('$uname', '$pwd')";
  
  if (!$conn -> query($sql)) {
    printf("%d Row inserted.\n", $conn->affected_rows);
  }
echo("<meta http-equiv='refresh' content='1'>");
}

if(isset($_POST['signupButton'])){ //check if form was submitted
  signupFunction();
 } 

 function loginFunction(){
  global $conn;

  $uname = $conn -> real_escape_string($_POST['uname']);
  $pwd = $conn -> real_escape_string($_POST['pwd']);

  $sql = "SELECT id,username,pwd FROM users where username='$uname' and pwd='$pwd' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $_SESSION['user']=$row["username"];
  }
} else {
  echo "0 results";
}


echo("<meta http-equiv='refresh' content='1'>");
}

if(isset($_POST['loginButton'])){ //check if form was submitted
  loginFunction();
 } 

 function nmovieFunction(){
  global $conn;

  $title = $conn -> real_escape_string($_POST['title']);
  $descr = $conn -> real_escape_string($_POST['descr']);

  
 $sql="INSERT INTO movies (title , descr, adate ) VALUES ('$title', '$descr', now())";
  
 if (!$conn -> query($sql)) {
  printf("%d Row inserted.\n", $conn->affected_rows);
 }

echo("<meta http-equiv='refresh' content='1'>");
}

if(isset($_POST['nmovieButton'])){ //check if form was submitted
  nmovieFunction();
 } 


?>

